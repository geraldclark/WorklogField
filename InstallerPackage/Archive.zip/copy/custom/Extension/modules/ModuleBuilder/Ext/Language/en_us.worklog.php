<?php

$mod_strings['fieldTypes']['worklog'] = 'Worklog';
