<?php

$mod_strings['LBL_WORKLOG'] = 'Worklog';
$mod_strings['LBL_WORKLOG_FORMAT_HELP'] = '';
