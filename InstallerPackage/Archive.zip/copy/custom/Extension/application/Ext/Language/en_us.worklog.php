<?php

//filters
$app_strings['LBL_WORKLOG_OPERATOR_CONTAINS'] = 'contains';
$app_strings['LBL_WORKLOG_OPERATOR_NOT_CONTAINS'] = 'does not contain';

//toggles
$app_strings['LBL_WORKLOG_PREVIOUS'] = 'previous';
$app_strings['LBL_WORKLOG_MORE'] = 'more';
$app_strings['LBL_WORKLOG_LESS'] = 'less';